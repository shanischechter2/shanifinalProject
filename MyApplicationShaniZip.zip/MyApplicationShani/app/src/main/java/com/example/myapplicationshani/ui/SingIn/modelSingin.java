package com.example.myapplicationshani.ui.SingIn;

import android.content.Context;

import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.firebaseHelper;
import com.google.firebase.auth.FirebaseAuth;

public class
modelSingin {
    DateBaseHelper dateBaseHelper;
    firebaseHelper fire;

    public modelSingin(Context context){
        this.fire=new firebaseHelper();
        this.dateBaseHelper=new DateBaseHelper(context);
        dateBaseHelper.onCreate2(dateBaseHelper);
    }

    public Boolean create(String nameS,String emailS,String phonS,String passS,Context context)
    {
        return fire.creatWithEmailAndPassword(nameS,emailS,phonS,passS,dateBaseHelper,context);

    }
}
