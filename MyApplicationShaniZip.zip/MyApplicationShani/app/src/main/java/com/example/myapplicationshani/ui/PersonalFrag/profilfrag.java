package com.example.myapplicationshani.ui.PersonalFrag;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.User;
import com.example.myapplicationshani.repostry.MyFotoAdapter;
import com.example.myapplicationshani.ui.Update.UpdatePropil;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


public class profilfrag extends Fragment {

    ImageView imagePropil;
    TextView posts,followers,following,bio,username;
    Button editpropil;

    FirebaseUser firebaseUser;
    String profileid;

    ImageButton myfotos,savedfotos;
    modelPersonalFrag modelPersonalFrag;
    RecyclerView recyclerView;
    MyFotoAdapter myFotoAdapter;
    List<Post> postList;
    List<String> mySaved;
    RecyclerView recyclerView_save;
    MyFotoAdapter myFotoAdapter_save;
    List<Post> postList_save;
    List<String> list;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_profilfrag, container, false);

        modelPersonalFrag=new modelPersonalFrag();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        SharedPreferences prefs= getActivity().getSharedPreferences("PREPS", Context.MODE_PRIVATE);
        profileid=prefs.getString("profileid","none");
        //modelPersonalFrag.setuserProfile();

        imagePropil=view.findViewById(R.id.imagePropilforfragP);

        posts=view.findViewById(R.id.postsforfragP);
        followers=view.findViewById(R.id.followersforfragP);
        following=view.findViewById(R.id.followingforfragP);
        bio=view.findViewById(R.id.bio);
        username=view.findViewById(R.id.usernameforfragP);
        editpropil=view.findViewById(R.id.edit_propilFrag);
        myfotos=view.findViewById(R.id.my_fotos);
        savedfotos=view.findViewById(R.id.saved_fotos);
        modelPersonalFrag.setuserProfile(imagePropil,getContext(),profileid);

        recyclerView=view.findViewById(R.id.recycleViewformyPotos);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new GridLayoutManager(getContext(),3);
        recyclerView.setLayoutManager(linearLayoutManager);
        postList=new ArrayList<>();
        myFotoAdapter=new MyFotoAdapter(getContext(),postList);
        recyclerView.setAdapter(myFotoAdapter);

        recyclerView_save=view.findViewById(R.id.recycleViewforsavedPotos);
        recyclerView_save.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager2=new GridLayoutManager(getContext(),3);
        recyclerView_save.setLayoutManager(linearLayoutManager2);
        postList_save=new ArrayList<>();
        myFotoAdapter_save=new MyFotoAdapter(getContext(),postList_save);
        recyclerView_save.setAdapter(myFotoAdapter_save);

        recyclerView.setVisibility(View.VISIBLE);
        recyclerView_save.setVisibility(View.GONE);

        userInfo();
        getFollowers();
        getNrPost();
        myFotos();
        mysaves();
        String id=firebaseUser.getUid();

        if(profileid.equals(id)){

            editpropil.setText("Edit profile");

        }else {
            checkFollow();
            savedfotos.setVisibility(View.GONE);
        }


        editpropil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String btn=editpropil.getText().toString();
                if(btn.equals("Edit profile"))
                {
                    //Toast.makeText(getContext(), "dd", Toast.LENGTH_SHORT).show();

                    SharedPreferences.Editor editor=getContext().getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                    editor.putString("profileid",profileid);
                    editor.apply();
                    moveToNewActivity();
                    //startActivity(new Intent(getContext(), UpdatePropil.class));
                }else
                {
                    if(btn.equals("follow")){
                        FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                .child("following").child(profileid).setValue(true);
                        FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                .child("followers").child(profileid).setValue(true);

                        addNotifications();

                    }else {
                        if(btn.equals("following")){
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("following").child(profileid).removeValue();
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("followers").child(profileid).removeValue();
                        }
                    }
                }
            }
        });
        myfotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerView.setVisibility(View.VISIBLE);
                recyclerView_save.setVisibility(View.GONE);
            }
        });

        savedfotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerView.setVisibility(View.GONE);
                recyclerView_save.setVisibility(View.VISIBLE);
            }
        });



        return view;
    }
    private void moveToNewActivity () {

        Intent i = new Intent(getActivity(), UpdatePropil.class);
        startActivity(i);
        ((Activity) getActivity()).overridePendingTransition(0, 0);

    }
    private void addNotifications(){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Notification").child(profileid);

        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("userid",firebaseUser.getUid());
        hashMap.put("text","started following you");
        hashMap.put("postid","");
        hashMap.put("ispost",false);

        reference.push().setValue(hashMap);
    }

    private void userInfo()
    {
//
//        if(getContext()==null)
//        {
//            return;
//        }
//        modelPersonalFrag.setuserProfile(imagePropil,getContext());
//        modelPersonalFrag.setusername(username);
//        modelPersonalFrag.setuserDef(bio);
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("users").child(profileid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(getContext()==null)
                {
                    return;
                }
                User user=snapshot.getValue(User.class);
                username.setText(user.getUsername());

//                modelPersonalFrag.setuserProfile(imagePropil,getContext());
//                modelPersonalFrag.setusername(username);
//                modelPersonalFrag.setuserDef(bio);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void checkFollow(){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Follow")
                .child(firebaseUser.getUid()).child("following");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(profileid).exists())
                {
                    editpropil.setText("following");
                }else {
                    editpropil.setText("follow");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void getFollowers()
    {
        DatabaseReference reference =FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(profileid).child("followers");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                followers.setText(""+dataSnapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference reference2 =FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(profileid).child("following");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                following.setText(""+dataSnapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void getNrPost(){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=0;
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    Post post=snapshot.getValue(Post.class);
                    if(post.getPublisher().equals(profileid))
                    {
                        i++;
                    }
                }

                posts.setText(""+i);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void myFotos()
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postList.clear();
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    Post post=snapshot.getValue(Post.class);
                    if(post.getPublisher().equals(profileid))
                    {
                        postList.add(post);
                    }
                }
                Collections.reverse(postList);
                myFotoAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void mysaves(){
       mySaved =new ArrayList<>();

       DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Saves").child(firebaseUser.getUid());
       reference.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                   mySaved.add(dataSnapshot.getKey());
               }
                 readSaves();
           }

           @Override
           public void onCancelled(@NonNull DatabaseError error) {

           }
       });
    }

    private void readSaves(){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                postList_save.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Post post=dataSnapshot.getValue(Post.class);

                    for (String id:mySaved){
                        if(post.getPostid().equals(id)){
                            postList_save.add(post);
                        }
                    }
                }
                myFotoAdapter_save.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}