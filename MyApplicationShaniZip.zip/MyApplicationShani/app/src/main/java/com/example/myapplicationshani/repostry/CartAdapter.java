package com.example.myapplicationshani.repostry;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplicationshani.ui.Cart.Cart;
import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.User;
import com.example.myapplicationshani.ui.PotoDitelFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

//פעולה המטפלת בכרטיסים ובאירועים של העגלת קניות

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder>{

    private Context mContext;
    private List<Cart> mCart;
    private FirebaseUser firebaseUser;

//פעולה בונה לאדפטר המקבלת  context
    public CartAdapter(Context mContext, List<Cart> mCart) {
        this.mContext = mContext;
        this.mCart = mCart;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.cart_card,parent,false);
        return new CartAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cart cart=mCart.get(position);
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        holder.price.setText(cart.getPrice());

        getUserInfo(holder.userpublishernme,cart.getUserid());

        if(cart.isIssold()){
            holder.PostImg.setVisibility(View.GONE);

        }else {
            holder.PostImg.setVisibility(View.VISIBLE);
            getPostImg(holder.PostImg,cart.getPostid());
        }
        holder.PostImg.setOnClickListener(new View.OnClickListener() {
            @Override


            public void onClick(View v) {
                SharedPreferences.Editor editor=mContext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("postid",cart.getPostid());
                editor.apply();

                ((FragmentActivity)mContext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new PotoDitelFragment()).commit();
            }
        });
//        holder.remove.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                FirebaseDatabase.getInstance().getReference().child("Carted").child(firebaseUser.getUid())
//                        .child(cart.getPostid()).removeValue();
//
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return mCart.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{
           ImageView PostImg;
           TextView userpublishernme,price;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            PostImg=itemView.findViewById(R.id.ingPostCart);
         //   remove=itemView.findViewById(R.id.mozarRemoveCart);
            userpublishernme=itemView.findViewById(R.id.usernameCartV);
            price=itemView.findViewById(R.id.mozarCratPrice);
        }
    }
    private void getUserInfo(final TextView username,String pubisherid){
        SharedPreferences prefs= mContext.getSharedPreferences("PREPS", Context.MODE_PRIVATE);
        String  profileid=prefs.getString("profileid","none");
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("users").child(profileid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

              //
               // prefs.edit();
                User user=snapshot.getValue(User.class);
                username.setText(user.getUsername());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void getPostInfo(final TextView price,String pubisherid){
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Cart").child(pubisherid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user=snapshot.getValue(User.class);
                price.setText(user.getUsername());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void getPostImg(final ImageView imageView,final String postid){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Post post=snapshot.getValue(Post.class);
                Glide.with(mContext).load(post.getPostimg()).into(imageView);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
