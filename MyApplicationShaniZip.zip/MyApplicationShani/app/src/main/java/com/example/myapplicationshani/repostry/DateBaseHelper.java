package com.example.myapplicationshani.repostry;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.myapplicationshani.User;
import com.example.myapplicationshani.ui.Login.LoginActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.security.AccessControlContext;

public class DateBaseHelper extends SQLiteOpenHelper {
    Context context;
    private static final String DATABASE_NAME = "ComputerList.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "List";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_PASS = "_pass";
    private static final String COLUMN_NAME = "_name";
    private static final String COLUMN_PHONE = "_phone";
    private static final String COLUMN_POST = "_post";
    private String IDS;

    firebaseHelper firebaseHelper1;
   public DateBaseHelper(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
        firebaseHelper1=new firebaseHelper();

    }




    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String query = "CREATE TABLE " + TABLE_NAME + " (" + COLUMN_ID +
                " TEXT PRIMARY KEY, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_PHONE + " TEXT, " + COLUMN_PASS + " TEXT);";

        db.execSQL(query);
        //COLUMN_POST + " TEXT, " +
       // firebaseHelper1.addToSQL();
        //onCreate2(this);

    }
   // @Override
   public void onCreate2(DateBaseHelper D)
    {
        firebaseHelper1.addToSQL(D);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public Boolean addUser(String email, String pass,String name,String phone)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_PASS, pass);
        cv.put(COLUMN_ID,email);
        cv.put(COLUMN_PHONE,phone);
       // cv.put(COLUMN_POST,post);


       long result=db.insert(TABLE_NAME,null,cv);
     //   long result = db.insert(TABLE_NAME,null, cv);

        if(result == -1)
        {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_SHORT).show();
            //firebaseHelper1.creatWithEmailAndPassword(name,email,phone,pass,context);
//
            return true;
        }
    }

    public Cursor readAllData()
    {
        //String query = "SELECT " + COLUMN_ID + ", " + COLUMN_NAME + ", " + COLUMN_PRICE + " FROM " + TABLE_NAME;
        String query2 = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null)
        {
            cursor = db.rawQuery(query2, null);
        }
        return cursor;
    }


    public void updateData(String row_id, String name, double price)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        cv.put(COLUMN_NAME, name);
      //  cv.put(COLUMN_PRICE, price);

        long result = db.update(TABLE_NAME, cv, "_id=?", new String[]{row_id});

        if(result == -1)
        {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Updated Successfully!", Toast.LENGTH_SHORT).show();
        }

    }

    public void deleteOneRow(String row_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME,COLUMN_ID+" =?",new String[]{row_id});
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Delete Successfully!", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }
    public String isnumberex(String num,String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_ID  + ", " + COLUMN_PASS + ", " + COLUMN_PHONE + " FROM " + TABLE_NAME;
        // String Query = "SELECT " + COLUMN_PASS + " FROM " + TABLE_NAME;
        Cursor cursor = null;
//        Cursor cursor2 = null;
        String found = "";
        try {
            if (db != null) {
                cursor = db.rawQuery(query, null);
                //        cursor2 = db.rawQuery(Query, null);
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        String emailFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                        String passFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_PASS));
                        String phoneFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE));

                        if (emailFromCursor != null && emailFromCursor.equals(email)&& phoneFromCursor.equals(num)&&phoneFromCursor!=null&&passFromCursor!=null) {
                            found = passFromCursor;

                            IDS=emailFromCursor;
                            break;
                        }
                    } while (cursor.moveToNext());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                //  cursor2.close();
            }
        }

        if (!found.equals("")) {
            // Toast.makeText(context, "Successfully!", Toast.LENGTH_SHORT).show();
//            FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
//              if(user!=null)
//              {
//               FirebaseAuth.getInstance().signOut();
//
        }

        return found;


    }
    public Boolean LogIn(String email,String pass)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_ID  + ", "+ COLUMN_PASS + " FROM " + TABLE_NAME;
       // String Query = "SELECT " + COLUMN_PASS + " FROM " + TABLE_NAME;
        Cursor cursor = null;
//        Cursor cursor2 = null;
        boolean found = false;
        try {
            if (db != null) {
                cursor = db.rawQuery(query, null);
        //        cursor2 = db.rawQuery(Query, null);
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        String emailFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                        String passFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_PASS));

                        if (emailFromCursor != null && emailFromCursor.equals(email)&& passFromCursor.equals(pass)&&passFromCursor!=null) {
                            found = true;
                            IDS=emailFromCursor;
                            break;
                        }
                    } while (cursor.moveToNext());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
              //  cursor2.close();
            }
        }

        if (found) {
           // Toast.makeText(context, "Successfully!", Toast.LENGTH_SHORT).show();
//            FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
//              if(user!=null)
//              {
//               FirebaseAuth.getInstance().signOut();
//              }
               firebaseHelper1.signInWithEmailAndPassword(email,pass);
        }

        return found;
    }
    public void deleteAllData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }
//    public String Get()
//    {
//        String s="";
//        SQLiteDatabase db = this.getReadableDatabase();
//        String query = "SELECT " + COLUMN_NAME + " FROM " + TABLE_NAME;
//        String query2 = "SELECT " + COLUMN_NAME + " FROM " + TABLE_NAME + "WHERE" + COLUMN_ID+" =?"+IDS;
//        Cursor cursor = null;
//        try {
//            if (db != null) {
//                cursor = db.rawQuery(query2, null);
//                //        cursor2 = db.rawQuery(Query, null);
//                if (cursor != null && cursor.moveToFirst()) {
//                    do {
//                        String emailFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
//                       // String passFromCursor = cursor.getString(cursor.getColumnIndex(COLUMN_PASS));
//
//                        if (emailFromCursor != null) {
//                            //found = true;
//                         //   IDS=emailFromCursor;
//                            s=emailFromCursor;
//                            break;
//                        }
//                    } while (cursor.moveToNext());
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//                //  cursor2.close();
//            }
//        }
//        return s;
//        db.close();
//
//    }

}
