package com.example.myapplicationshani.ui.HomeFrag;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplicationshani.ui.Notification.NotificationsFragment;
import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.repostry.PostAdapter;
import com.example.myapplicationshani.ui.searchFragment.searchFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class newHomeFrag extends Fragment {
    TextView wellcom;
    ImageView imageView,serch;
    private RecyclerView recyclerView;
    private PostAdapter postAdapter;
    modelHomeFrag homeFrag;
    private List<Post> postLists;
    private List<String> flowingList;
    searchFragment serchF =new searchFragment();
    NotificationsFragment notificationsFragment=new NotificationsFragment();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_new_home, container, false);
        recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        postLists = new ArrayList<>();
        postAdapter = new PostAdapter(getContext(), postLists);
        recyclerView.setAdapter(postAdapter);

        wellcom = view.findViewById(R.id.wellcomeText9);
        serch = view.findViewById(R.id.serchHomePage);
        imageView = view.findViewById(R.id.like3);
        homeFrag=new modelHomeFrag(getContext());
        homeFrag.setUserNAme(wellcom);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().beginTransaction().replace(R.id.f_con, notificationsFragment).commit();
            }
        });
        serch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(Home.this, "ssss", Toast.LENGTH_SHORT).show();
                getParentFragmentManager().beginTransaction().replace(R.id.f_con, serchF).commit();
            }
        });


       // checkFollowing();
        homeFrag.post(flowingList,postLists,postAdapter);

        return view;

    }
    public void checkFollowing()
    {
        flowingList=new ArrayList<>();

        DatabaseReference reference =FirebaseDatabase.getInstance().getReference("Follow")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("following");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                flowingList.clear();
                for (DataSnapshot snapshot:dataSnapshot.getChildren())
                {
                    flowingList.add(snapshot.getKey());
                }
                readPosts();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void readPosts()
    {
        //postLists=new ArrayList<>();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postLists.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Post post=snapshot.getValue(Post.class);
                    for (String id : flowingList) {
                        if (post.getPublisher().equals(id)) {
                            postLists.add(post);
                        }
                    }

                }
                postAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Toast.makeText(Home.this, "cant", Toast.LENGTH_SHORT).show();
            }
        });

    }
}