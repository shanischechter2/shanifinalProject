package com.example.myapplicationshani.ui.Notification;

import com.example.myapplicationshani.repostry.NotificationAdapter;
import com.example.myapplicationshani.repostry.firebaseHelper;

import java.util.List;

public class NotificationModel {
    firebaseHelper fire;

    public NotificationModel() {
        this.fire = new firebaseHelper();
    }

    public void readnot(List<Notification> notificationList, NotificationAdapter notificationAdapter)
    {
        fire.readNotification(notificationList,notificationAdapter);
    }
}
