package com.example.myapplicationshani.ui.searchFragment;

import android.widget.EditText;

import com.example.myapplicationshani.User;
import com.example.myapplicationshani.repostry.UserAdapter;
import com.example.myapplicationshani.repostry.firebaseHelper;

import java.util.List;

public class searchfragmodel {

    private firebaseHelper fire;

    public searchfragmodel()
    {
        this.fire=new firebaseHelper();
    }

    public void readU(EditText search_bar, List<User> mUsers, UserAdapter userAdapter)
    {
        fire.readUsers(search_bar,mUsers,userAdapter);
    }
    public void serchUsers(String s,List<User> mUsers,UserAdapter userAdapter){
        fire.searchUsers(s,mUsers,userAdapter);
    }
}
