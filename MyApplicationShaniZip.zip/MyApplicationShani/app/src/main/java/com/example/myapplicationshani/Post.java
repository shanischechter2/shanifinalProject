package com.example.myapplicationshani;

public class Post {
    private String postid;
    private String postimg;
    private String description;
    private String publisher;
    private String price;

     public Post()
     {

     }
    public Post(String postid, String postimg, String description, String publisher,String price) {
        this.postid = postid;
        this.postimg = postimg;
        this.description = description;
        this.publisher = publisher;
        this.price=price;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid;
    }

    public String getPostimg() {
        return postimg;
    }

    public void setPostimg(String postimg) {
        this.postimg = postimg;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
}
