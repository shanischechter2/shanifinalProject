package com.example.myapplicationshani.ui.MainActivity;

import android.content.Context;

import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.firebaseHelper;

import java.security.AccessControlContext;

public class modelMainActivity {
    firebaseHelper fire;
    DateBaseHelper dateBaseHelper;

    public modelMainActivity(Context context) {
        this.fire=new firebaseHelper();
        this.dateBaseHelper=new DateBaseHelper(context);
       // dateBaseHelper.onCreate2(dateBaseHelper);
    }

//    public Boolean isLoged()
//    {
//       //return fire.IsUserLogedin();
//    }
    public void addTOSQL(Context context){
        //fire.addToSQL(context);
    }
    public void del()
    {
        dateBaseHelper.deleteAllData();
    }

}
