package com.example.myapplicationshani.ui.HomeFrag;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.PostAdapter;
import com.example.myapplicationshani.repostry.firebaseHelper;

import java.util.List;

public class modelHomeFrag {

     DateBaseHelper dateBaseHelper;
    firebaseHelper fire;


    public modelHomeFrag(Context context) {
        this.fire=new firebaseHelper();
        this.dateBaseHelper=new DateBaseHelper(context);
        dateBaseHelper.onCreate2(dateBaseHelper);
    }
    public void post(List<String> flowingList, List<Post> postList, PostAdapter postAdapter){
        fire.checkFollowing(flowingList,postList,postAdapter);
    }
    public void setUserNAme(TextView T)
    {
        fire.setuserName(T);

    }
    public String getUserid()
    {
       return fire.getUid();

    }
    public void setpost(View v, Context context, LinearLayout layout)
    {
        fire.setPost(v,context,layout);
    }



}
