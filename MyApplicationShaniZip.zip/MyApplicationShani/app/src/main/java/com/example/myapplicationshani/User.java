package com.example.myapplicationshani;

import android.widget.ImageView;

public class User {
    public String username;
    public String email;
    public String phon;
    public String pass;

    public String userFirebaseid;


    public User() {

    }

    public User(String username, String email,String phon,String pass,String id) {
        this.username = username;
        this.email = email;
        this.phon=phon;
        this.pass=pass;
        this.userFirebaseid=id;

    }

    public String getUserFirebaseid() {
        return userFirebaseid;
    }

    public void setUserFirebaseid(String userFirebaseid) {
        this.userFirebaseid = userFirebaseid;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhon(String phon) {
        this.phon = phon;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }


    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPhon() {
        return phon;
    }

    public String getPass() {
        return pass;
    }
}
