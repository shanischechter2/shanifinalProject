package com.example.myapplicationshani.repostry;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.User;
import com.example.myapplicationshani.ui.PersonalFrag.profilfrag;
import com.example.myapplicationshani.ui.PotoDitelFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    public Context mComtext;
    public List<Post> mPost;

    private FirebaseUser firebaseUser;

    public PostAdapter(Context mComtext, List<Post> mPost) {
        this.mComtext = mComtext;
        this.mPost = mPost;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mComtext).inflate(R.layout.post_item, parent, false);

        return new PostAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        Post post=mPost.get(position);
        Glide.with(mComtext).load(post.getPostimg()).into(holder.imgpost);

        if(post.getDescription().equals("")){
            holder.description.setVisibility(View.GONE);
        }else {
            holder.description.setVisibility(View.VISIBLE);
            holder.description.setText(post.getDescription());
        }

        publisherInfo(holder.imgpropil,holder.username,holder.publisher,post.getPublisher());
        isLiked(post.getPostid(),holder.like);
        nrLikes(holder.likesnum,post.getPostid());
        isSaved(post.getPostid(), holder.save);
        pricen(holder.price, post.getPostid());
        isCarted(post.getPostid(),holder.addtocart);

        holder.imgpropil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=mComtext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("profileid",post.getPublisher());
                editor.apply();

                ((FragmentActivity)mComtext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new profilfrag()).commit();
            }
        });
        holder.username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=mComtext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("profileid",post.getPublisher());
                editor.apply();

                ((FragmentActivity)mComtext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new profilfrag()).commit();
            }
        });
        holder.publisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=mComtext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("profileid",post.getPublisher());
                editor.apply();

                ((FragmentActivity)mComtext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new profilfrag()).commit();
            }
        });
        holder.imgpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=mComtext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("postid",post.getPostid());
                editor.apply();

                ((FragmentActivity)mComtext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new PotoDitelFragment()).commit();
            }
        });

        holder.save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.save.getTag().equals("save"))
                {
                    FirebaseDatabase.getInstance().getReference().child("Saves").child(firebaseUser.getUid())
                            .child(post.getPostid()).setValue(true);
                }else {
                    FirebaseDatabase.getInstance().getReference().child("Saves").child(firebaseUser.getUid())
                            .child(post.getPostid()).removeValue();
                }
            }
        });

        holder.addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.addtocart.getTag().equals("cart"))
                {
                    SharedPreferences.Editor editor=mComtext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                    editor.putString("profileid",post.getPublisher());
                    editor.apply();
                    FirebaseDatabase.getInstance().getReference().child("Carted").child(firebaseUser.getUid())
                            .child(post.getPostid()).setValue(true);

                    addtocart(firebaseUser.getUid(),post.getPostid(),post.getPrice());
                }else {
                    FirebaseDatabase.getInstance().getReference().child("Carted").child(firebaseUser.getUid())
                            .child(post.getPostid()).removeValue();
                }

            }
        });
        holder.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.like.getTag().equals("like")){
                    FirebaseDatabase.getInstance().getReference().child("Likes").child(post.getPostid())
                            .child(firebaseUser.getUid()).setValue(true);

                    addNotifications(post.getPublisher(),post.getPostid());
                }else {
                    FirebaseDatabase.getInstance().getReference().child("Likes").child(post.getPostid())
                            .child(firebaseUser.getUid()).removeValue();
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return mPost.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgpropil, imgpost, like, save,addtocart;
        public TextView username, likesnum, publisher, description,price;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgpost = itemView.findViewById(R.id.post_imege);
            imgpropil = itemView.findViewById(R.id.profil_img);
            like = itemView.findViewById(R.id.like);
            addtocart = itemView.findViewById(R.id.addCart);
            save = itemView.findViewById(R.id.savePost);
            username = itemView.findViewById(R.id.userName_post);
            likesnum = itemView.findViewById(R.id.post_likes);
            publisher = itemView.findViewById(R.id.post_publisher);
            description = itemView.findViewById(R.id.post_descripsion);
            price=itemView.findViewById(R.id.postPriceShow);


        }
    }
    private void pricen(final TextView likes,String postid)
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Post post=snapshot.getValue(Post.class);
                likes.setText(post.getPrice());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void isLiked(String postid ,final ImageView imageView)
    {
        final FirebaseUser firebaseUser1=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference()
                .child("Likes")
                .child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(firebaseUser1.getUid()).exists()){
                    imageView.setImageResource(R.drawable.favorite_24);
                    imageView.setTag("liked");
                }else
                {
                    imageView.setImageResource(R.drawable.like_24);
                    imageView.setTag("like");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void isCarted(String postid ,final ImageView imageView)
    {
        final FirebaseUser firebaseUser1=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference()
                .child("Carted")
                .child(firebaseUser1.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(postid).exists()){
                    imageView.setImageResource(R.drawable.baseline_verified_24);
                    imageView.setTag("carted");
                }else
                {
                    imageView.setImageResource(R.drawable.add_shopping_cart_24);
                    imageView.setTag("cart");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    private void addNotifications(String userid,String postid){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Notification").child(userid);

        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("userid",firebaseUser.getUid());
        hashMap.put("text","like your post");
        hashMap.put("postid",postid);
        hashMap.put("ispost",true);

        reference.push().setValue(hashMap);
    }
    private void addtocart(String userid,String postid,String price){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Cart").child(userid).child(postid);

        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("userid",firebaseUser.getUid());
        hashMap.put("price",price);
        hashMap.put("postid",postid);
        hashMap.put("issold",false);

        reference.setValue(hashMap);
    }
    private void isSaved(final String postid,final ImageView imageView)
    {
        FirebaseUser firebaseUser1=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Saves")
                .child(firebaseUser1.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(postid).exists()){
                    imageView.setImageResource(R.drawable.baseline_bookmark_24);
                    imageView.setTag("saved");
                }else {
                    imageView.setImageResource(R.drawable.save_24);
                    imageView.setTag("save");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void nrLikes(final TextView likes,String postid)
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Likes").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                likes.setText(snapshot.getChildrenCount()+" likes");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void publisherInfo(final  ImageView imgPropil,final TextView username,final TextView publisher,final String userId)
    {
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("users").child(userId);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                    User user=snapshot.getValue(User.class);
                    username.setText(user.getUsername());
                    publisher.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
