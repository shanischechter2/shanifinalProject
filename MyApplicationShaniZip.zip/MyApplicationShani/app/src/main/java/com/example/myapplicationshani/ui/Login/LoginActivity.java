package com.example.myapplicationshani.ui.Login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplicationshani.R;
import com.example.myapplicationshani.ui.Home.Home;
import com.example.myapplicationshani.ui.SingIn.SingIn;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class LoginActivity extends AppCompatActivity {
    EditText pass,email;
    Button log;
    TextView sing,passremaider;
    FirebaseAuth auth;
    ProgressDialog dialogP;
    static DatabaseReference mDatabase;
    modleLogin modleL;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        pass=findViewById(R.id.passL);
        passremaider=findViewById(R.id.porgotpass);
        email=findViewById(R.id.emelL);
        log=findViewById(R.id.log);
//
//     //   mDatabase = FirebaseDatabase.getInstance().getReference();
        sing=findViewById(R.id.sing);
//      //  auth=FirebaseAuth.getInstance();
        modleL=new modleLogin(LoginActivity.this);
//      //  modleL.del();
        sing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SingIn.class));
            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogP=new ProgressDialog(LoginActivity.this);
                dialogP.setMessage("Logging in");
                dialogP.show();
                String Spass=pass.getText().toString().trim();
                String Semail=email.getText().toString().trim();
                if (TextUtils.isEmpty(Semail)||TextUtils.isEmpty(Spass))
                {
                    Toast.makeText(LoginActivity.this, "fill all", Toast.LENGTH_SHORT).show();
                    dialogP.dismiss();
                }else
                {
                 //  Boolean b= modleL.login(Semail,Spass);
//                    DateBaseHelper dateBaseHelper=new DateBaseHelper(LoginActivity.this);
//                    dateBaseHelper.onCreate2(dateBaseHelper);
                  Boolean b=  modleL.login(Semail,Spass);
                    if (b)
                    {
                        dialogP.dismiss();
                          //Toast.makeText(LoginActivity.this, "Yes", Toast.LENGTH_SHORT).show();
                          startActivity(new Intent(getApplicationContext(), Home.class));
                    }
                    else
                    {
                          dialogP.dismiss();
                         //Toast.makeText(LoginActivity.this, "cant", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
        passremaider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


//                if(ContextCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
//                    sendtext("0587809030","heyyyyy");
//                }
//                else {
//                    ActivityCompat.requestPermissions(LoginActivity.this,new String[]{Manifest.permission.SEND_SMS},100);
//                }


             // String s=  modleL.getPhone();
                Dialog dialog = new Dialog(LoginActivity.this);
                dialog.setCancelable(true);

                dialog.setContentView(R.layout.cuspumdaylogpassword);
                Button send=dialog.findViewById(R.id.sendToMail);
           //     Button goBack=dialog.findViewById(R.id.sendToMail);
                EditText emailpre=dialog.findViewById(R.id.emailforRestartPass);
                EditText ppre=dialog.findViewById(R.id.PhoneforRestartPass);

                dialog.show();

                send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //sendtext("0587809030","rrrr");
                        String TrimEmail=emailpre.getText().toString().trim();
                        String TrimP=ppre.getText().toString().trim();
                        if(TextUtils.isEmpty(TrimEmail)&&TextUtils.isEmpty(TrimP))
                        {
                           emailpre.setError("anter your email");
                        }
                        else {
                            String pass=modleL.resetPass(TrimEmail,TrimP);
                            if (pass.equals(""))
                            {
                                Toast.makeText(LoginActivity.this, "no found", Toast.LENGTH_SHORT).show();
                            }else
                            {
                                if(ContextCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
                                    sendtext(TrimP,pass);
                                }
                                else {
                                    ActivityCompat.requestPermissions(LoginActivity.this,new String[]{Manifest.permission.SEND_SMS},100);
                                }
                            }
//                            Intent intent=new Intent(Intent.ACTION_SEND);
//                            intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"shanischechter4@gmail.com"});
//                            intent.putExtra(Intent.EXTRA_SUBJECT,"pass remider");
//                            intent.putExtra(Intent.EXTRA_TEXT,"pass");
//                            intent.setType("message/rfc822");
//                            startActivity(Intent.createChooser(intent,"Choose email client:"));

                           // modleL.resetPass(TrimEmail,LoginActivity.this);
                        }

                    }
                });

              //  modleL.resetPass();

//                if(ContextCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED)
//
//
//                {
//
//                }else
//                {
//                    ActivityCompat.requestPermissions(LoginActivity.this,new String[]{Manifest.permission.SEND_SMS},100);
//                }
            }
        });

    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//
//        if(requestCode==100&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
//            sendtext("0587809030","hheyyy");
//        }else {
//            Toast.makeText(this, "pramishen denaid", Toast.LENGTH_SHORT).show();
//        }
//    }

    public void sendtext(String number, String text) {
        SmsManager smsManager=SmsManager.getDefault();

        smsManager.sendTextMessage(number,null,text,null,null);
       // Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
    }





}