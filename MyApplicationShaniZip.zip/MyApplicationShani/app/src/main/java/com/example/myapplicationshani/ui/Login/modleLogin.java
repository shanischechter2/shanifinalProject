package com.example.myapplicationshani.ui.Login;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.firebaseHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class modleLogin {

    firebaseHelper fire;
    DateBaseHelper dateBaseHelper;
    public modleLogin(Context context) {
        this.fire=new firebaseHelper();
       this.dateBaseHelper=new DateBaseHelper(context);
       // del();
        dateBaseHelper.onCreate2(dateBaseHelper);
    }
   public Boolean login(String e,String p)
   {
    return dateBaseHelper.LogIn(e,p);

   }
   public String resetPass(String email,String p)
     {
        return dateBaseHelper.isnumberex(p,email);
      // fire.porgotPass(s,context);
   }
    public void del()
    {
        dateBaseHelper.deleteAllData();
    }




}
