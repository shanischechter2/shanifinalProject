package com.example.myapplicationshani.ui.Cart;

import android.widget.TextView;

import com.example.myapplicationshani.repostry.CartAdapter;
import com.example.myapplicationshani.repostry.firebaseHelper;

import java.util.List;

public class modelCart {
    firebaseHelper fire;

    public modelCart() {
        this.fire = new firebaseHelper();
    }
    public void mycart2(List<String> list, List<Cart> cartList, CartAdapter cartAdapter, TextView t)
    {
        this.fire.mycart(list,cartList,cartAdapter,t);
    }
}
