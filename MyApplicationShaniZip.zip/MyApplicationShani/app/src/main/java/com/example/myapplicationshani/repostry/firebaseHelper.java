package com.example.myapplicationshani.repostry;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.User;
import com.example.myapplicationshani.ui.Cart.Cart;
import com.example.myapplicationshani.ui.Notification.Notification;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class firebaseHelper  {
    FirebaseAuth auth ;
    private Boolean fLogin=true;
   private Boolean fSingin=false;


    StorageReference storageReference;

   private String GetUserNameS="";
    DatabaseReference mDatabase;
    FirebaseUser user;
  //  AuthFireBase authFireBase;

    public firebaseHelper() {
        this.auth = FirebaseAuth.getInstance();
   //     authFireBase=new AuthFireBase();
    //    dateBaseHelper=new DateBaseHelper(this);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        this.user=FirebaseAuth.getInstance().getCurrentUser();
        storageReference= FirebaseStorage.getInstance().getReference();





    }
    public void addToSQL(DateBaseHelper dateBaseHelper)
    {
     //   Context context1= new Context(firebaseHelper.this);

       // dateBaseHelper=new DateBaseHelper(context);
        dateBaseHelper.deleteAllData();
        mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot postSnapshot: snapshot.getChildren())
                {
                    User user1=postSnapshot.getValue(User.class);
                    dateBaseHelper.addUser(user1.email,user1.pass,user1.username,user1.phon);

                  //  dateBaseHelper.addUser(user1);



                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public FirebaseAuth getAuth() {
        return auth;
    }

//    public void porgotPass(String s,Context context)
//    {
//        auth.sen(s).addOnCompleteListener(new OnCompleteListener<Void>() {
//            @Override
//            public void onComplete(@NonNull Task<Void> task) {
//                 if(task.isSuccessful())
//                 {
//                     Toast.makeText(context, "check your email", Toast.LENGTH_SHORT).show();
//                 }
//                 else {
//                     Toast.makeText(context, "cant find email", Toast.LENGTH_SHORT).show();
//                 }
//            }
//        });
//


 //   }
 public void checkFollowing(List<String> flowingList,List<Post>postList,PostAdapter postAdapter)
 {
     flowingList=new ArrayList<>();

     DatabaseReference reference =FirebaseDatabase.getInstance().getReference("Follow")
             .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
             .child("following");

     List<String> finalFlowingList = flowingList;
     reference.addValueEventListener(new ValueEventListener() {
         @Override
         public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
             finalFlowingList.clear();
             for (DataSnapshot snapshot:dataSnapshot.getChildren())
             {
                 finalFlowingList.add(snapshot.getKey());
             }
             readPosts(finalFlowingList,postList,postAdapter);

         }

         @Override
         public void onCancelled(@NonNull DatabaseError error) {

         }
     });
 }
    public void searchUsers(String s,List<User> mUsers,UserAdapter userAdapter)
    {
        Query query= FirebaseDatabase.getInstance().getReference("users").orderByChild("username")
                .startAt(s)
                .endAt(s+"\uf8ff");

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUsers.clear();
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    User user=snapshot.getValue(User.class);
                    mUsers.add(user);
                }
                userAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void readUsers(EditText search_bar, List<User> mUsers,UserAdapter userAdapter)
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("users");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(search_bar.getText().toString().equals(""))
                {
                    mUsers.clear();
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                        User user=snapshot.getValue(User.class);
                        mUsers.add(user);
                    }

                    userAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void readNotification(List<Notification> notificationList,NotificationAdapter notificationAdapter)
    {
        FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Notification").child(firebaseUser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                notificationList.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren())
                {
                    Notification notification=dataSnapshot.getValue(Notification.class);
                    notificationList.add(notification);
                }
                Collections.reverse(notificationList);
                notificationAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void readPosts(List<String> flowingList,List<Post> postList,PostAdapter postAdapter)
    {
        //postLists=new ArrayList<>();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Post post=snapshot.getValue(Post.class);
                    for (String id : flowingList) {
                        if (post.getPublisher().equals(id)) {
                            postList.add(post);
                        }
                    }

                }
                postAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Toast.makeText(Home.this, "cant", Toast.LENGTH_SHORT).show();
            }
        });

    }
 public void mycart(List<String> list,List<Cart> cartList,CartAdapter cartAdapter,TextView t){
     list =new ArrayList<>();

     DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Carted").child(getUid());
     List<String> finalList = list;
     reference.addValueEventListener(new ValueEventListener() {
         @Override
         public void onDataChange(@NonNull DataSnapshot snapshot) {
             for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                 finalList.add(dataSnapshot.getKey());
             }
             readSaves(finalList,cartList,cartAdapter,t);
         }

         @Override
         public void onCancelled(@NonNull DatabaseError error) {

         }
     });
 }
    private void readSaves(List<String>list,List<Cart> cartList,CartAdapter cartAdapter,TextView t){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Cart").child(getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cartList.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Cart post=dataSnapshot.getValue(Cart.class);

                    for (String id:list){
                        if(post.getPostid().equals(id)){
                            cartList.add(post);
                        }
                    }
                }
                cartAdapter.notifyDataSetChanged();
                int sun=0;
                for (int i = 0; i <cartList.size() ; i++) {
                    String s=cartList.get(i).getPrice().toString();
                    //
                    int m=Integer.parseInt(s);
                    sun+=m;

                }
                String s=Integer.toString(sun);
                t.setText(s);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void setPost2(Uri imgUri,String uri,String dec,String price){

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts");
        String postid=reference.push().getKey();

        Post post=new Post(postid,uri,dec,FirebaseAuth.getInstance().getCurrentUser().getUid(),price);
        reference.child(post.getPostid()).setValue(post);
    }

    public void UpdetPropilPhoto( Uri selectedImageUri)
    {
        storageReference.child("imegPro").child(user.getUid()).putFile(selectedImageUri);
    }

    public void UpdateDef(String n)
    {
       // UsetPro user2 = new UsetPro(n);
       //    mDatabase.child("users_def").child(user.getUid()).setValue(user2);
    }
    public void UpdateName(String n)
    {
       // UsetPro user2 = new UsetPro(n);
        mDatabase.child("users").child(user.getUid()).child("username").setValue(n);
    }
    public void UpdatePhone(String n)
    {
        // UsetPro user2 = new UsetPro(n);
        mDatabase.child("users").child(user.getUid()).child("phon").setValue(n);
    }

//  public void UpdatePropilpic(Uri imageViewURI)
//  {
//      storageReference.child("imegPro").child(user.getUid()).putFile(imageViewURI);
//  }
  public String getUid()
  {
     return user.getUid();
  }
    public void propilpic(ImageView propilPoto, Context context,String s){
        storageReference.child("imegPro/").child(s).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                if(uri!=null)
                {
                 //   uPRO=uri;
                    Glide.with(context).load(uri).into(propilPoto);

                }
            //    else
                   // Toast.makeText(getContext(), "null", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {

            }
        });
    }
    public void setPost(View view, Context context, LinearLayout layout){
        mDatabase.child("userPosts").child(user.getUid()).child("uri").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String s = snapshot.getValue().toString();
                    Uri uri=Uri.parse(s);
                //    int s2 = Integer.parseInt(s);
                   // for (int i = 1; i <= s2; i++) {
                      //  String in = Integer.toString(i);
                        //View vie=getLayoutInflater().inflate(R.layout.post_item,null);
                      //  storageReference.child("posts/").child(user.getUid() + "/").child(in).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                       //     @Override
                        //    public void onSuccess(Uri uri) {
                                if (uri != null) {
                                    //   uPRO=uri;
                                    View view1 = View.inflate(context, R.layout.post_item, null);
                                    ImageView Poto = view1.findViewById(R.id.post_imege);
                                    ImageView propilPoto = view1.findViewById(R.id.profil_img);
                                    Poto.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                                    TextView name = view1.findViewById(R.id.userName_post);
                                    Glide.with(context).load(uri).into(Poto);
                                   // propilpic(propilPoto, context);
                                    setuserName(name);
                                   // mDatabase.child("users").child(user.getUid()).child("postCount").setValue(in);
                                    layout.addView(view1);


                                //}


                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception exception) {
//
//
//                            }
//                        });
                   // }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        }


       // scrollView.addView(layout);


    public void addposttoFire(Uri uri, Context context, ImageView imageView)
    {
        String d2="";

       // User U=new User();

        mDatabase.child("users").child(user.getUid()).child("postCount").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
              //  int c=0;
                if(snapshot.exists()) {
                  //  c++;
                    String c = snapshot.getValue().toString();

                    int con=Integer.parseInt(c);
                    int c2=con+1;
                    String d= Integer.toString(c2);
                    String uriS=uri.toString();
                    mDatabase.child("userPosts").child(user.getUid()).child("uri").child(d).setValue(uriS);
                      //U.postCount=d;
                   // storageReference.child("posts").child(user.getUid()).child(d).putFile(uri);
                   // mDatabase.child("users").child(user.getUid()).child("postCount").setValue(d);


                    Toast.makeText(context, "yaes", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
     //   storageReference.child("posts").child(user.getUid()).child(U.postCount).putFile(uri);

    }

    public void setuserName(TextView Tt)
    {
        String uid=user.getUid();

         DatabaseReference mDatabase2= FirebaseDatabase.getInstance().getReference().child("users");
         mDatabase2.child(uid).child("username").addValueEventListener(new ValueEventListener() {
           // @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               //f=true;
                if(snapshot.exists())
                {
                     String s1=snapshot.getValue().toString();
                 //   b=true;
                     Tt.setText(s1);
                 //     sw=s1;
                  //    getGetUserName(GetUserNameS)


                   // f=true;
                    ;
                   // wellcom.setText("Welcome back "+s);
                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });


    }


    public void signInWithEmailAndPassword(String email, String pass) {
//       Boolean[] f = new Boolean[2];
//       f[0]=new Boolean(true);
//       f[1]=false;
        Boolean b=fLogin;

      //  task2=new
        auth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    user=FirebaseAuth.getInstance().getCurrentUser();

                //    Toast.makeText(context, "cjdjvnjdgnjdrifngijrd", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    public Boolean creatWithEmailAndPassword(String nameS,String emailS,String phonS,String passS,DateBaseHelper dateBaseHelper,Context context)
    {

        auth.createUserWithEmailAndPassword(emailS,passS).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
     //       @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {

                    String Userid=auth.getCurrentUser().getUid();

                    User user2 = new User(nameS, emailS,phonS,passS,user.getUid());
                    Toast.makeText(context, "yyyyy", Toast.LENGTH_SHORT).show();
                    mDatabase.child("users").child(Userid).setValue(user2);
                    // documentReference.set(user);
                    dateBaseHelper.addUser(emailS,passS,nameS,phonS);
                    //      startActivity(new Intent(getApplicationContext(),Home.class));

                    fSingin=true;
                }
                else
                {

                  //  dialogP.dismiss();
                    Toast.makeText(context, "cant"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
                //   return null;
            }
        });

        return  fSingin;
    }
    public void getdef(TextView t)
    {
        mDatabase.child("users_def").child(user.getUid()).child("def").addValueEventListener(new ValueEventListener() {

            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String s = snapshot.getValue().toString();
                   // Getdef=s;
                   t.setText(s);

                }
                else
                {
                   // Getdef=null;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
        //return Getdef;
    }





}
