package com.example.myapplicationshani.ui.Cart;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplicationshani.R;
import com.example.myapplicationshani.repostry.CartAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class cartFragment extends Fragment {

    Button button;
    TextView Tprice;
    RecyclerView recyclerView;
    CartAdapter cartAdapter;
    List<Cart> cartList;
    FirebaseUser firebaseUser;
    String claintid="AW60NXO5ys4xdX1sKQM9CgQINgmcL83-MXAKv6hGpNfI0ZJpVMyzgd8rT6ghzv4KQvKEPBZfBXPj0FHU";

    int PayPal_Code=123;
    modelCart modelC;
    public static PayPalConfiguration configuration;
    List<String> list;
    String profileid;
    @SuppressLint({"MissingInflatedId", "WrongConstant"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_cart,container,false);
        view.setClickable(true);
        view.setFocusable(true);
        button=view.findViewById(R.id.b);
        Tprice=view.findViewById(R.id.sumPrice);
        modelC=new modelCart();
//
//        SharedPreferences prefs= getActivity().getSharedPreferences("PREPS", Context.MODE_PRIVATE);
//        profileid=prefs.getString("profileid","none");
        configuration=new PayPalConfiguration().environment(PayPalConfiguration.ENVIRONMENT_SANDBOX).clientId(claintid);

        recyclerView=view.findViewById(R.id.recycleViewCart);
        recyclerView.setHasFixedSize(true);


        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        RecyclerView.LayoutParams params = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 0);
        mLayoutManager.canScrollVertically();
        recyclerView.setLayoutManager(mLayoutManager);
        cartList=new ArrayList<>();
        cartAdapter=new CartAdapter(getContext(),cartList);
        recyclerView.setAdapter(cartAdapter);
        recyclerView.setVisibility(View.VISIBLE);
        //firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

      //  mycart();
        modelC.mycart2(list,cartList,cartAdapter,Tprice);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPayment();
              //  cartList.clear();
            }
        });



        return view;
    }
//    private void myCart()
//    {
//        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Carted").child(firebaseUser.getUid());
//
//        reference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                cartList.clear();
//                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
//                    Cart post=snapshot.getValue(Cart.class);
//                    if(post.getUserid().equals(firebaseUser.getUid()))
//                    {
//                        cartList.add(post);
//                    }
//                }
//                Collections.reverse(cartList);
//                cartAdapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
//    private void mycart(){
//        list =new ArrayList<>();
//
//        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Carted").child(firebaseUser.getUid());
//        reference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
//                    list.add(dataSnapshot.getKey());
//                }
//                readSaves();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
//    private void readSaves(){
//        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Cart").child(firebaseUser.getUid());
//
//        reference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                cartList.clear();
//                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
//                    Cart post=dataSnapshot.getValue(Cart.class);
//
//                    for (String id:list){
//                        if(post.getPostid().equals(id)){
//                            cartList.add(post);
//                        }
//                    }
//                }
//                cartAdapter.notifyDataSetChanged();
//                int sun=0;
//                for (int i = 0; i <cartList.size() ; i++) {
//                    String s=cartList.get(i).getPrice().toString();
//                   //
//                    int m=Integer.parseInt(s);
//                    sun+=m;
//
//                }
//                String s=Integer.toString(sun);
//                Tprice.setText(s);
//
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
   private void getPayment(){
        String amunt=Tprice.getText().toString();

       PayPalPayment payment=new PayPalPayment(new BigDecimal(String.valueOf(amunt)),"USD","Code with Arvind",PayPalPayment.PAYMENT_INTENT_SALE);

       Intent intent=new Intent(getContext(), PaymentActivity.class);
       intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,configuration);
       intent.putExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_PAYMENT,payment);

       startActivityForResult(intent,PayPal_Code);
   }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==PayPal_Code){
            PayPalConfiguration payPalConfiguration=data.getParcelableExtra(com.paypal.android.sdk.payments.PaymentActivity.EXTRA_RESULT_CONFIRMATION);

            if(payPalConfiguration!=null){


                try {

                    String paymentDatils=payPalConfiguration.toString();
                    JSONObject object =new JSONObject(paymentDatils);
                   // Toast.makeText(getContext(), "ss", Toast.LENGTH_SHORT).show();

                }catch (JSONException e){
                   // throw new RuntimeException(e);
                    Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }else if (requestCode== Activity.RESULT_CANCELED){
                Toast.makeText(getContext(), "error", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode== com.paypal.android.sdk.payments.PaymentActivity.RESULT_EXTRAS_INVALID) {
            Toast.makeText(getContext(), "Invald paypant", Toast.LENGTH_SHORT).show();
            
        }
    }

    }