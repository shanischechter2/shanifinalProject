package com.example.myapplicationshani.ui.AddPost;

import androidx.activity.result.ActivityResult;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.ui.Home.Home;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import org.w3c.dom.Text;

import java.util.HashMap;

public class add extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    Uri imageUri;
 String imgUrlStrig;
 StorageTask uplodeTask;

 EditText discrip,price;


 ImageView close,added;
 TextView post;
 StorageReference storageReference;
    FirebaseAuth auth;
    modelAddCart modelAddCart1;
    String Userid;
 private  final  int GALERY=1000;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        discrip=findViewById(R.id.post_descripsion);
        price=findViewById(R.id.mozarPrice);

        auth=FirebaseAuth.getInstance();
        Userid=auth.getCurrentUser().getUid();
        modelAddCart1=new modelAddCart();
        close=findViewById(R.id.close);
        added=findViewById(R.id.postImg);
        post=findViewById(R.id.postP);
        storageReference= FirebaseStorage.getInstance().getReference("posts");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(add.this, Home.class));
                finish();
            }
        });

//        Intent inGallry=new Intent(Intent.ACTION_PICK);
//     inGallry.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//     startActivityForResult(inGallry,GALERY);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                added.getDrawable();
                upLoadImg();



            }
        });


        added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
             //    Toast.makeText(add.this, "SSS", Toast.LENGTH_SHORT).show();
            }
        });


    }
    public void upLoadImg()
    {
        ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("posting");
        progressDialog.show();
        if(imageUri!=null)
        {
           final StorageReference filerefrence=storageReference.child(System.currentTimeMillis()
                   + "."+ getFileExten(imageUri));
           uplodeTask=filerefrence.putFile(imageUri);
           uplodeTask.continueWithTask(new Continuation() {
               @Override
               public Object then(@NonNull Task task) throws Exception {
                   if(!task.isSuccessful())
                   {
                       throw task.getException();
                   }
                   return filerefrence.getDownloadUrl();
               }
           }).addOnCompleteListener(new OnCompleteListener<Uri>() {
               @Override
               public void onComplete(@NonNull Task<Uri> task) {
                   if(task.isSuccessful())
                   {
                       Uri downloadUri=task.getResult();
                       imgUrlStrig=downloadUri.toString();
//
//                      // DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts");
//                     //  String postid=reference.push().getKey();
//                       HashMap<String,Object> hashMap=new HashMap<>();
//                      // hashMap.put("postid",postid);
//                       hashMap.put("postimg",imgUrlStrig);
//                       hashMap.put("description",discrip.getText().toString());
//                       hashMap.put("publisher",FirebaseAuth.getInstance().getCurrentUser().getUid());
//                    //   Post post1=new Post(postid,imgUrlStrig,,FirebaseAuth.getInstance().getCurrentUser().getUid(),price.getText().toString());
//
//                     //  reference.child(postid).setValue(post1);
                       modelAddCart1.addposttoFireB(imageUri,imgUrlStrig,discrip.getText().toString(),price.getText().toString());
                       progressDialog.dismiss();

                       startActivity(new Intent(add.this,Home.class));

                   }
                   else {
                       Toast.makeText(add.this, "faild", Toast.LENGTH_SHORT).show();
                   }
               }
           }).addOnFailureListener(new OnFailureListener() {
               @Override
               public void onFailure(@NonNull Exception e) {
                   Toast.makeText(add.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
               }
           });


        }else {
            Toast.makeText(this, "No imge slected", Toast.LENGTH_SHORT).show();
        }
    }
    public String getFileExten(Uri uri)
    {
        ContentResolver contentResolver=getContentResolver();
        MimeTypeMap mime=MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();
            imageUri=selectedImageUri;

            // Now you can do something with the selected image URI
            // For example, display the image in an ImageView
            ImageView imageView = findViewById(R.id.postImg);
            imageView.setImageURI(selectedImageUri);
           // modelAddCart1.addposttoFireB(selectedImageUri,add.this,imageView);
           // storageReference.child("posts").child(Userid).child("2").putFile(selectedImageUri);
            //Toast.makeText(this, Userid, Toast.LENGTH_SHORT).show();

        }
    }
}