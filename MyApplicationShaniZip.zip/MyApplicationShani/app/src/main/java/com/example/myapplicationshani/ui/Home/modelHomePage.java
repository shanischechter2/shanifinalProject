package com.example.myapplicationshani.ui.Home;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.firebaseHelper;

public class modelHomePage {
    firebaseHelper fire;


    DateBaseHelper dateBaseHelper;



    public modelHomePage(Context context) {
        this.fire=new firebaseHelper();
        this.dateBaseHelper=new DateBaseHelper(context);
        dateBaseHelper.onCreate2(dateBaseHelper);
    }
    public void setUserNAme(TextView T)
    {
        fire.setuserName(T);

    }

    public void setpost(View v, Context context, LinearLayout layout)
    {
        fire.setPost(v,context,layout);
    }
}
