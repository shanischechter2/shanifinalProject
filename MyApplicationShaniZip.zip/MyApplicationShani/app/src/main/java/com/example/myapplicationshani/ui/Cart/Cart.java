package com.example.myapplicationshani.ui.Cart;

public class Cart {
    private String userid;
    private String price;
    private String postid;
    private boolean issold;

    public Cart(String userid, String price, String postid, boolean issold) {
        this.userid = userid;
        this.price = price;
        this.postid = postid;
        this.issold = issold;
    }

    public Cart() {
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid;
    }

    public boolean isIssold() {
        return issold;
    }

    public void setIssold(boolean issold) {
        this.issold = issold;
    }
}
