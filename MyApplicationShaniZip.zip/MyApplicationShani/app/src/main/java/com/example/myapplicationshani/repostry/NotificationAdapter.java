package com.example.myapplicationshani.repostry;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplicationshani.ui.Notification.Notification;
import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.R;
import com.example.myapplicationshani.User;
import com.example.myapplicationshani.ui.PersonalFrag.profilfrag;
import com.example.myapplicationshani.ui.PotoDitelFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder>{

    private Context mContext;
    private List<Notification> mNotification;

    public NotificationAdapter(Context mContext, List<Notification> mNotification) {
        this.mContext = mContext;
        this.mNotification = mNotification;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.notification_item,parent,false);
        return new NotificationAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Notification notification=mNotification.get(position);

        holder.text1.setText(notification.getText());

        getUserInfo(holder.image_propil,holder.username1,notification.getUserid());

        if(notification.isIspost()){
            holder.image_post.setVisibility(View.VISIBLE);
            getPostImg(holder.image_post,notification.getPostid());
        }else {
            holder.image_post.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(notification.isIspost()){
                    SharedPreferences.Editor editor=mContext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                    editor.putString("postid",notification.getPostid());
                    editor.apply();

                    ((FragmentActivity)mContext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new PotoDitelFragment()).commit();

                }else {
                    SharedPreferences.Editor editor=mContext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                    editor.putString("profileid",notification.getUserid());
                    editor.apply();

                    ((FragmentActivity)mContext).getSupportFragmentManager().beginTransaction().replace(R.id.f_con,new profilfrag()).commit();
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return mNotification.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{
         public ImageView image_propil,image_post;
         public TextView username1,text1;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image_post=itemView.findViewById(R.id.NotificationImgPost);
            image_propil=itemView.findViewById(R.id.NotificationImgPropil);
            username1=itemView.findViewById(R.id.NotificationUserName);
            text1=itemView.findViewById(R.id.NotificationComment);
        }
    }
    private void getUserInfo(final ImageView imageView,final TextView username,String pubisherid){
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("users").child(pubisherid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user=snapshot.getValue(User.class);
                username.setText(user.getUsername());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void getPostImg(final ImageView imageView,final String postid){
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("posts").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Post post=snapshot.getValue(Post.class);
                Glide.with(mContext).load(post.getPostimg()).into(imageView);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
