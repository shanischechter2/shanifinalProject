package com.example.myapplicationshani.ui.PersonalFrag;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplicationshani.repostry.DateBaseHelper;
import com.example.myapplicationshani.repostry.firebaseHelper;

public class modelPersonalFrag {
    firebaseHelper fire;

    public modelPersonalFrag() {
        this.fire=new firebaseHelper();

    }
    public void setusername(TextView t)
    {
        fire.setuserName(t);
    }
    public void setuserDef(TextView t)
    {
       fire.getdef(t);
    }
    public void setuserProfile(ImageView u, Context context,String p)
    {
        fire.propilpic(u,context,p);
    }
    public void setpost(View v, Context context, LinearLayout layout)
    {
        fire.setPost(v,context,layout);
    }



}
