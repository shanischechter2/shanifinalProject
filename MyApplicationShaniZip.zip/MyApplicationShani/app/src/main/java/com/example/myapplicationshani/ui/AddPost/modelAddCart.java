package com.example.myapplicationshani.ui.AddPost;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.widget.ImageView;

import com.example.myapplicationshani.repostry.firebaseHelper;
import com.example.myapplicationshani.ui.Home.Home;

public class modelAddCart {

    firebaseHelper fire;
    public modelAddCart()
    {
        this.fire=new firebaseHelper();
    }

    public void addposttoFireB(Uri uri2,String uri,String dec,String price)
    {
        fire.setPost2(uri2,uri,dec,price);
    }
}
