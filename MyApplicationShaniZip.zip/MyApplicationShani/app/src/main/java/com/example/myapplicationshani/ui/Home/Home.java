package com.example.myapplicationshani.ui.Home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.myapplicationshani.Post;
import com.example.myapplicationshani.repostry.PostAdapter;
import com.example.myapplicationshani.ui.searchFragment.searchFragment;
import com.example.myapplicationshani.ui.HomeFrag.newHomeFrag;
import com.example.myapplicationshani.R;

import com.example.myapplicationshani.ui.AddPost.add;
import com.example.myapplicationshani.ui.Cart.cartFragment;

import com.example.myapplicationshani.ui.PersonalFrag.profilfrag;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class Home extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    TextView userNamePropile;
    private DatabaseReference mDatabase;
    modelHomePage homePage;




    cartFragment CartFragment=new cartFragment();
    newHomeFrag newHome=new newHomeFrag();
    searchFragment serchF =new searchFragment();
    profilfrag profil=new profilfrag();



    private DrawerLayout drawerLayout;

    String Userid;
    NavigationView NavigationView2;
    TextView wellcom;
    ImageView imageView,serch;
    private RecyclerView recyclerView;
    private PostAdapter postAdapter;
    private List<Post> postLists;
    private List<String> flowingList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bottomNavigationView = findViewById(R.id.bottomMahvrimView);
        homePage = new modelHomePage(Home.this);

        getSupportFragmentManager().beginTransaction().replace(R.id.f_con,newHome).commit();
        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {


            Boolean flag = false;

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()) {
                    case R.id.home:
//
                }
                //   getSupportFragmentManager().beginTransaction().replace(R.id.f_container,PersonalFragment).commit();
                return false;
            }
        });
//
//
        findViewById(R.id.home).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(Home.this, PersonalActivity.class));
                getSupportFragmentManager().beginTransaction().replace(R.id.f_con,newHome).commit();

            }
        });
        findViewById(R.id.personal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(Home.this, PersonalActivity.class));
                SharedPreferences.Editor editor=Home.this.getSharedPreferences("PREPS", Context.MODE_PRIVATE).edit();
                editor.putString("profileid",FirebaseAuth.getInstance().getCurrentUser().getUid());
                editor.apply();
                bottomNavigationView.setSelectedItemId(R.id.personal);
                getSupportFragmentManager().beginTransaction().replace(R.id.f_con,profil).commit();

            }
        });
        findViewById(R.id.cart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.f_con,CartFragment).commit();
               // startActivity(new Intent(Home.this, cartActivityTwo.class));
            }
        });
        findViewById(R.id.plos).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomNavigationView.setSelectedItemId(R.id.plos);
                startActivity(new Intent(Home.this, add.class));
            }
        });


    }



}